import React from 'react'

const Header = () => {
  return (
    <div className='header'> 
        <h1 className='title'>Notes</h1>
    </div>
  )
}

export default Header